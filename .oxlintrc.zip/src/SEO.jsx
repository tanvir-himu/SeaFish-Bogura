
import { useEffect } from "react";

const SITE_URL = "https://seafishbogura.netlify.app";

const seoData = {
  home: {
    title: "SeaFish Bogura | Buy Sea Fish Online in Bangladesh",
    description:
      "Buy Hilsa, Bhetki, Churi and Loitta fish online from SeaFish Bogura. Explore our sea fish collection and order through WhatsApp.",
    path: "/",
  },

  contact: {
    title: "Contact Us | SeaFish Bogura",
    description:
      "Contact SeaFish Bogura through WhatsApp, phone or Facebook for sea fish prices, orders and customer support.",
    path: "/contact",
  },

  privacy: {
    title: "Privacy Policy | SeaFish Bogura",
    description:
      "Read the SeaFish Bogura Privacy Policy to learn how customer information is collected, used and protected.",
    path: "/privacy-policy",
  },
};

export default function SEO({ page = "home" }) {
  const data = seoData[page] || seoData.home;

  useEffect(() => {
    document.title = data.title;

    const setMeta = (attribute, key, content) => {
      let element = document.head.querySelector(
        `meta[${attribute}="${key}"]`
      );

      if (!element) {
        element = document.createElement("meta");
        element.setAttribute(attribute, key);
        document.head.appendChild(element);
      }

      element.setAttribute("content", content);
    };

    setMeta("name", "description", data.description);
    setMeta("property", "og:title", data.title);
    setMeta("property", "og:description", data.description);
    setMeta("property", "og:url", SITE_URL + data.path);

    let canonical = document.querySelector(
      'link[rel="canonical"]'
    );

    if (!canonical) {
      canonical = document.createElement("link");
      canonical.rel = "canonical";
      document.head.appendChild(canonical);
    }

    canonical.href = SITE_URL + data.path;
  }, [data]);

  return null;
}
